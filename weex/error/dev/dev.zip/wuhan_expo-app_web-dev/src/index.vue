<template>
  <div class="wrapper">
    <router-view />
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style scoped>
.wrapper {
  background-color: rgba(238,238,238,1);
}
</style>
